//
//  CollectionViewController.swift
//  MusicPlayer
//
//  Created by Nathan Jamrog on 2024-04-18.
//

import Foundation
import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}

